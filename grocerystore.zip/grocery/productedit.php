<!----Display Particular Order Details---->
<?php
$id=$_GET['prid'];
 $con=mysqli_connect("localhost","root","","grocery");
 $query="select *from tbl_product where prid='$id'";
 $res=mysqli_query($con,$query);
 $row=mysqli_fetch_array($res);
 $na = $row['name'];
 $pr = $row['price'];
 $ty= $row['type'];
  if (isset($_POST['sub'])) {
    $na = $_POST['name'];
    $pr = $_POST['price'];
    $ty= $_POST['type'];
    $filename = $_FILES["image"]["name"];
    $con=mysqli_connect("localhost","root","","grocery");
    $query="update tbl_product set  name='$na',price='$pr', type='$ty' where prid='$id'";
    $re=mysqli_query($con,$query);
    if ($re) {
        if($ty=='veg'){
            $targetDir = "images\veg/";
            $targetfilepath = $targetDir . $filename;
            move_uploaded_file($_FILES["image"]["tmp_name"], $targetfilepath);
        }
        else if($ty=='fru'){
            $targetDir = "images\fru/";
            $targetfilepath = $targetDir . $filename;
            move_uploaded_file($_FILES["image"]["tmp_name"], $targetfilepath);
        }
        else if($ty=='meat'){
            $targetDir = "images\meat/";
            $targetfilepath = $targetDir . $filename;
            move_uploaded_file($_FILES["image"]["tmp_name"], $targetfilepath);
        }
       
  ?>
        <script>
          alert("Product Added successfully");	
        </script>";

      <?php
        header('Location:product.php');
      } else {
      ?>
        <script>
          alert("Insertion failed");
        </script>
  <?php
      }
    }
   
  ?>


<!doctype html>
<html>

<head>
	<title>Online Grocery Shop</title>
	<meta name="Author" content="">
	<meta name="Keywords" content="">
	<meta name="Description" content="">
	<!--font awesome/6 cdn-->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
	<!--external stylesheet-->
	<link rel="stylesheet" href="eatfresh.css" />
	<script>
		function stickyMenu() {
			var sticky = document.getElementById('sticky');
			if (window.pageYOffset > 220) {
				sticky.classList.add('sticky');
			} else {
				sticky.classList.remove('sticky');
			}
		}
		window.onscroll = function() {
			stickyMenu();
		}
	</script>
	<style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: "Poppins", sans-serif;
    }

    body {
        background-image:url('images/background.jpg');
        height:max-content;
		  background-attachment:fixed;
		  background-position:center;
		  background-repeat:no-repeat;
		  background-size:cover;
    }

    .container {
      margin: 100px;
      width: 628px;
      background: #FDFEFE ;
      border-radius: 6px;
      margin-top: 116px;
      margin-left: 400px;
      padding: 40px;
      box-shadow: -10px 10px 10px 10px rgba(0, 0, 0, 0.2);
    }

    .container .content {
      display: flex;
      align-items: center;

    }

    .container .content .right-side {
      width: 75%;
      margin-left: 75px;
    }

    .content .right-side .topic-text {
      font-size: 23px;
      font-weight: 600;
      color:#27AE60   ;
    }

    .right-side .input-box {
      height: 50px;
      width: 100%;
      margin: 20px 0;
    }

    .right-side .input-box input,
    .right-side .input-box textarea {
      height: 100%;
      width: 100%;
      border: none;
      outline: none;
      font-size: 16px;
      background: #ABEBC6 ;
      border-radius: 6px;
      padding: 0 15px;
    }

    .right-side .message-box {
      min-height: 110px;
    }

    .right-side .input-box textarea {
      padding-top: 6px;
    }

    .right-side .button {
      display: inline-block;
      margin-top: 12px;
    }

    .btn {
      background-color: #DDD1F8;
      color: rgb(0, 0, 0);
      border: 2px solid black;
      padding: 5px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 20px;
      margin: 4px 4px;
      cursor: pointer;
      border-radius: 10px;
      width: 100%;
    }
    .box {
        height: 100%;
      width: 100%;
      border: none;
      outline: none;
      font-size: 16px;
      background: #ABEBC6 ;
      border-radius: 6px;
      padding: 16px 15px;
      color:#566573   ;
      }
  </style>

	<style>
		img {
			border-radius: 50%;
		}
	</style>
</head>

<body>
	<div class="parallax">
		<div class="page-title">Eat Fresh</div>
	</div>
	<div class="menu" id="sticky">
    <ul class="menu-ul">
				<a href="adminpanel.php#" class="a-menu">
					<li>Home</li>
				</a>
				<a href="product.php" class="a-menu">
					<li>Products</li>
				</a>
				<a href="userdetails.php" class="a-menu">
					<li>Users</li>
				</a>
				<a href="logout.php" class="a-menu">
					<li>log Out</li>
				</a>
			</ul>
	</div>
	<div class="container">
    <div class="content">
      <div class="right-side">
        <div class="topic-text">EDIT EXISTING PRODUCT</div>
        <form id="form" method="post" enctype="multipart/form-data">
			<div class="input-box">
              <input type="text" placeholder="Enter Product Name" name="name" id="p1" value="<?php echo $na;?>" required />
            </div>

            <div class="input-box">
              <input type="text" placeholder="Enter Price" name="price" id="p4"value="<?php echo $pr;?>" required />
            </div>
            <div>
              <select name="type" class="box" ><option class="box"value="veg" value="<?php echo $ty;?>">Vegetable</option>
              <option class="box"value="fru">Fruit</option>
              <option class="box"value="meat">Meat</option>
    </select>
    </div>
            <div class="input-box">
              <input type="file" accept="image/png, image/gif, image/jpeg" placeholder="Upload image" name="image" value="<?php echo $filename?>" required>
            </div>
            <div class="button">
              <input type="submit" class="btn" name="sub" value="submit" />
            </div>
        </form>
      </div>
    </div>
  </div>
	<!---Footer starts here-->
	<div class="parallax1">
		<div class="footer">
			<div class="quick-links">
				<div>Stores</div>
				<ul>
					<li><a href="https://goo.gl/maps/rFauva4Ncj6HVmqN8" class="a-links">Puthuparambil stores</a>
					<li>
					<li><a href="https://goo.gl/maps/v7GPeRDVoUVXmxSYA" class="a-links">More Supermarket</a>
					<li>
					<li><a href="https://goo.gl/maps/7VqVW2X5uxdH5aDn7" class="a-links">Real Hyper Market</a>
					<li>
				</ul>
			</div>

			<div class="quick-links">
				<div>Careers</div>
				<ul>
					<li><a href="" class="a-links">Packing</a>
					<li>
					<li><a href="" class="a-links">Staffing</a>
					<li>
					<li><a href="" class="a-links">Delivery Agent</a>
					<li>
				</ul>
			</div>
			<div class="quick-links">
				<div>Quick Links</div>
				<ul>
					<li><a href="" class="a-links">Contact us</a>
					<li>
					<li><a href="" class="a-links">FAQ</a>
					<li>
					<li><a href="" class="a-links">Help</a>
					<li>
				</ul>
			</div>
		</div>
	</div>
	<div class="Copyrights">
		<i class="fast fa=copyright fa-1x">@2022 By Wilgimol Thomas</i>
	</div>

	<!---Footer Ends here-->
</body>

</html>