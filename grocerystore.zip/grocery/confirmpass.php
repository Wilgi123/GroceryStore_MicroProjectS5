<?php
session_start();
$lid = $_SESSION['id'];
$con = mysqli_connect("localhost", "root", "", "grocery");
$query = "select * from tbl_login where lid='$lid'";
$re = mysqli_query($con, $query);
$row = mysqli_fetch_array($re);
$cp = $row['password'];
if (isset($_POST['submit'])) {
    $ps = $_POST['password'];
    if ($ps == $cp) {
        header('Location: passchange.php');
    } else {
?>
        <script>
            alert("password does not match");
        </script>
<?php
    }
    mysqli_close($con);
}
?>
<!DOCTYPE html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="style.css">

    <title>Register Form</title>
</head>
<style>
    #error1,
    #error3,
    #error4,
    #error5,
    #error6,
    #error2,
    #error7 {
        color: #cc0033;
        font-family: Helvetica, Arial, sans-serif;
        font-size: 13px;
        font-weight: bold;
        line-height: 20px;
        text-shadow: 1px 1px rgba(250, 250, 250, .3);
    }

    .password-container {
        width: 100%;
        position: relative;
    }

    input,
    input[type=password] {
        width: 150px;
        height: 20px;
    }

    .fa-eye {
        position: absolute;
        top: 29%;
        right: 4%;
        cursor: pointer;
        color: lightgray;
    }
</style>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
        var ver1 = 1;
        $(document).ready(function() {
            $("#error3").hide();
            $("#error5").hide();
            var pass = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
            $("#p4").keyup(function() {
                x = document.getElementById("p4").value;
                if (pass.test(x) == false) {
                    ver1 = 1;
                    $("#error3").show();
                } else if (pass.test(x) == true) {
                    ver1 = 0;
                    $("#error3").hide();
                }
            });
            $("#submit").focus(function() {
                if (ver1 == 0)
                    $("#error5").hide();
                else
                    $("#error5").show();
            });
        });
    </script>
    
<body>
    <div class="container">
        <form action="#" method="POST" class="login-email" enctype="multipart/form-data">
            <p class="login-text" style="font-size: 2rem; font-weight: 800;">Confirm password</p>
            <div class="input-group">
                <div class="password-container">
                    <input type="password" placeholder=" Current Password" id="p4" name="password" required>
                    <i class="fa fa-fw fa-eye field_icon" id="toggle_pwd" style="margin-left: -30px; cursor: pointer;"></i>
                    <script type="text/javascript">
                        const togglePassword = document.querySelector('#toggle_pwd');
                        const password = document.querySelector('#p4');
                        togglePassword.addEventListener('click', function(e) {
                            // toggle the type attribute
                            const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
                            password.setAttribute('type', type);
                            // toggle the eye slash icon
                            this.classList.toggle('fa-eye-slash');
                        });
                    </script>
                </div>
            </div>
    
    <p id="error3">&nbsp; Password should match with current password.</p><br>
    <p id="error5">&nbsp;Please fill the form correctly.</p><br>
    <div class="input-group">
        <input type="submit" id="submit" name="submit" class="btn" value="Confirm">
    </div>
    </form>
    </div>
</body>

</html>