<?php
session_start();
$lid = $_SESSION['id'];
$sum=$_GET['sum'];
$date = date('d/m/Y', time());
$con = mysqli_connect("localhost", "root", "", "grocery");
$q1 = "select * from tbl_cart where lid='$lid'";
$re1 = mysqli_query($con, $q1);
if ($re1) {
	$q3 = "insert into tbl_orderd(date,lid,total) values('$date','$lid','$sum')";
	$re3 = mysqli_query($con, $q3);
}
if ($re3) {
	$last_id = mysqli_insert_id($con);
	while ($row1 = mysqli_fetch_array($re1)) {
		$na = $row1['name'];
		$prid = $row1['prid'];
		$pr = $row1['price'];
		$query = "insert into tbl_order(lid,oid,prid,name,price) values('$lid','$last_id','$prid','$na','$pr')";
		$re = mysqli_query($con, $query);
		$q4="update tbl_product set qty=qty-1 where prid='$prid'";
		$re4 = mysqli_query($con,$q4);
	}
}
if ($re) {
	$q2 = "delete from tbl_cart where lid='$lid'";
	$re2 = mysqli_query($con, $q2);
	if ($re2) {
?>
<script>
	alert("Order placed");
	window.location.href = "usergrocery.php";
</script>
<?php
	}
}
mysqli_close($con);

            ?>