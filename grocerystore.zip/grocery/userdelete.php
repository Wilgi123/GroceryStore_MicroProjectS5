<?php
        $id=$_GET['id'];
		$con=mysqli_connect("localhost","root","","grocery");
        $query1="select * from tbl_login where lid='$id'";
		$re1=mysqli_query($con,$query1);
        $row1=mysqli_fetch_array($re1);
        if($row1['admin']==1)
        {
            ?>
                <script>
                    alert("Admin user can not be deleted");
                    window.location.href = "userdetails.php";
                </script>
            <?php
        }
        else{
		$query="delete from tbl_reg where lid='$id'";
		$re=mysqli_query($con,$query);
        if($re)
        {
            $query1="delete from tbl_login where lid='$id'";
            $re1=mysqli_query($con,$query1);
            if($re1){
            ?>
                <script>
                    alert("User successfully deleted");
                    window.location.href = "userdetails.php";
                </script>
            <?php
            }
        }
        }
		mysqli_close($con);
	
?>