<!---Log Out page---->
<html>
<body>
    <?php
    session_start();
    session_unset();
    session_destroy();
    header("Location: grocery.php");
    ?>
</body>

</html>