<!----Register Form--->
<!DOCTYPE html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="style.css">

    <title>Register Form</title>
</head>
<style>
    #error1,
    #error3,
    #error4,
    #error5,
    #error6,
    #error2,
    #error7 {
        color: #cc0033;
        font-family: Helvetica, Arial, sans-serif;
        font-size: 13px;
        font-weight: bold;
        line-height: 20px;
        text-shadow: 1px 1px rgba(250, 250, 250, .3);
    }

    .password-container {
        width: 100%;
        position: relative;
    }

    input,
    input[type=password] {
        width: 150px;
        height: 20px;
    }

    .fa-eye {
        position: absolute;
        top: 29%;
        right: 4%;
        cursor: pointer;
        color: lightgray;
    }
</style>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
    var ver1 = 1;
    var ver2 = 1;
    var ver3 = 1;
    var ver4 = 1;
    var ver5 = 1;
    var ver6 = 1;
    var ver7 = 1;
    $(document).ready(function() {
        $("#error1").hide();
        $("#error2").hide();
        $("#error3").hide();
        $("#error4").hide();
        $("#error5").hide();
        $("#error7").hide();
        $("#error6").hide();
        var uname = /^[a-zA-Z0-9\-\_]+$/;
        $("#uname1").keyup(function() {
            x = document.getElementById("uname1").value;
            if (uname.test(x) == false) {
                ver3 = 1
                $("#error2").show();
            } else if (uname.test(x) == true) {
                ver3 = 0;
                $("#error2").hide();
            }
        });
        var name = /^[a-zA-Z ]{3,16}$/;
        $("#p1").keyup(function() {
            x = document.getElementById("p1").value;
            if (name.test(x) == false) {
                ver1 = 1
                $("#error1").show();
            } else if (name.test(x) == true) {
                ver1 = 0;
                $("#error1").hide();
            }
        });
        var ph = /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[789]\d{9}$/;
        $("#p7").keyup(function() {
            x = document.getElementById("p7").value;
            if (ph.test(x) == false) {
                ver2 = 1
                $("#error7").show();
            } else if (ph.test(x) == true) {
                ver2 = 0;
                $("#error7").hide();
            }
        });

        var mail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{3,4})+$/;
        $("#p3").keyup(function() {
            x = document.getElementById("p3").value;
            if (mail.test(x) == false) {
                ver4 = 1;
                $("#error3").show();
            } else if (mail.test(x) == true) {
                ver4 = 0;
                $("#error3").hide();
            }
        });
        var pass = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
        $("#p4").keyup(function() {
            x = document.getElementById("p4").value;
            if (pass.test(x) == false) {
                ver5 = 1;
                $("#error4").show();
            } else if (pass.test(x) == true) {
                ver5 = 0;
                $("#error4").hide();
            }
        });
        $("#p5").keyup(function() {
            pass1 = document.getElementById("p4").value;
            pass2 = document.getElementById("p5").value;
            if (pass1 != pass2) {
                ver6 = 1;
                $("#error5").show();
            } else if (pass1 == pass2) {
                ver6 = 0;
                $("#error5").hide();
            }
        });
        $("#submit").click(function() {
            if (ver1 == 0 && ver2 == 0 && ver3 == 0 && ver4 == 0 && ver5 == 0 && ver6 == 0 && ver7 == 0) {
                $("#error6").hide();
                return true;
            } else {
                $("#error6").show();
                return false;
            }
        });
    });

    function checkAvailability() {
        $("#loaderIcon").show();
        jQuery.ajax({
            url: "available.php",
            data: 'uname=' + $("#uname1").val(),
            type: "POST",
            success: function(data) {
                $("#user-availability-status").html(data);
            },
            error: function() {}
        });
    }

    function checkmailAvailability() {
        $("#loaderIcon").show();
        jQuery.ajax({
            url: "mailavailable.php",
            data: 'email=' + $("#p3").val(),
            type: "POST",
            success: function(data) {
                $("#mail-availability-status").html(data);
            },
            error: function() {}
        });
    }
</script>

<body>
    <div class="container">
        <form action="#" method="POST" class="login-email" enctype="multipart/form-data">
            <p class="login-text" style="font-size: 2rem; font-weight: 800;">Register</p>
            <div class="input-group">
                <input type="text" id="p1" placeholder="Name" name="name" required>
            </div>
            <p id="error1">&nbsp;Only alphabets are allowed</p>
            <div class="input-group">
                <input type="text" id="uname1" class="inputtext" placeholder="Enter username" required name="uname" onKeyup="checkAvailability()">
            </div>
            <p id="user-availability-status"></p>
            <p id="error2">&nbsp;Spaces and Special characters not allowed(Except _)</p>
            <div class="input-group">
                <input type="text" id="p7" class="inputtext" placeholder="Enter phone number" required name="phone">
            </div>
            <p id="error7">&nbsp;Enter a valid number</p>
            <div class="input-group">
                <input type="file" accept="image/png, image/gif, image/jpeg" placeholder="Profile Photo" name="photo" required>
            </div>
            <div class="input-group">
                <input type="email" id="p3" class="inputtext" placeholder="Enter email id"  name="mail" onKeyup="checkmailAvailability()" required>
            </div>
            <p id="mail-availability-status"></p>
            <p id="error3">&nbsp;Use a valid email address</p>
            <div class="input-group">
                <div class="password-container">
                    <input type="password" placeholder="Password..." id="p4" name="password" required>
                    <i class="fa fa-fw fa-eye field_icon" id="toggle_pwd" style="margin-left: -30px; cursor: pointer;"></i>
                    <script type="text/javascript">
                        const togglePassword = document.querySelector('#toggle_pwd');
                        const password = document.querySelector('#p4');
                        togglePassword.addEventListener('click', function(e) {
                            // toggle the type attribute
                            const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
                            password.setAttribute('type', type);
                            // toggle the eye slash icon
                            this.classList.toggle('fa-eye-slash');
                        });
                    </script>
                </div>
            </div>
            <p id="error4">&nbsp;Password should include at-least eight characters,uppercase letter,lowercase
                letter,number and special character.</p>
            <div class="input-group">
                <div class="password-container">
                    <input type="password" id="p5" placeholder="Confirm Password" name="cpassword" required>
                    <i class="fa fa-fw fa-eye field_icon" id="togglepwd" style="margin-left: -30px; cursor: pointer;"></i>
                    <script type="text/javascript">
                        const togglePassword2 = document.querySelector('#togglepwd');
                        const cppassword = document.querySelector('#p5');
                        togglePassword2.addEventListener('click', function(f) {
                            // toggle the type attribute
                            const type = cppassword.getAttribute('type') === 'password' ? 'text' : 'password';
                            cppassword.setAttribute('type', type);
                            // toggle the eye slash icon
                            this.classList.toggle('fa-eye-slash');
                        });
                    </script>
                </div>
            </div>
            <p id="error5">&nbsp;Both passwords should match.</p><br>
            <p id="error6">&nbsp;Please fill the form correctly.</p><br>
            <div class="input-group">
                <input type="submit" id="submit" name="submit" class="btn" value="Register">
            </div>
            <p class="login-register-text">Have an account? <a href="login.php">Login Here</a>.</p>
        </form>
    </div>
</body>

</html>
<?php
if (isset($_POST['submit'])) {
    $na = $_POST['name'];
    $ma = $_POST['mail'];
    $filename = $_FILES["photo"]["name"];
    $un = $_POST['uname'];
    $ph = $_POST['phone'];
    $ps = $_POST['password'];
    $con = mysqli_connect("localhost", "root", "", "grocery");
    $query = "insert into tbl_login(username,password,admin) values('$un','$ps',0)";
    $re = mysqli_query($con, $query);
    if ($re) {
        $last_id = mysqli_insert_id($con);
        $q = "insert into tbl_reg(lid,name,filename,email,phone,admin) values('$last_id','$na','$filename','$ma','$ph',0)";
        $res = mysqli_query($con, $q);
        if ($res) {
            $targetDir = "uploads/";
            $targetfilepath = $targetDir . $filename;
            move_uploaded_file($_FILES["photo"]["tmp_name"], $targetfilepath);
?>
            <script>
                alert("registration successful");
                window.location.href = "login.php";
            </script>
        <?php
        } else {
        ?>
            <script>
                alert("registration failed");
            </script>
<?php
        }
    }
    mysqli_close($con);
}
?>