<?php
if (isset($_POST['sub'])) {
    $id = $_GET['id'];
    $p1 = $_POST['carrot'];
    $p2 = $_POST['tomato'];
    $p3 = $_POST['cabbage'];
    $p4 = $_POST['betroot'];
    $p5 = $_POST['onion'];
    $p6 = $_POST['apple'];
    $p7 = $_POST['grapes'];
    $p8 = $_POST['orange'];
    $p9 = $_POST['cherry'];
    $p10 = $_POST['mango'];
    $p11 = $_POST['rambuttan'];
    $p12 = $_POST['chicken'];
    $p13 = $_POST['lamb'];
    $p14 = $_POST['prawns'];
    $p15 = $_POST['fish'];
    $p16 = $_POST['crab'];
    $con = mysqli_connect("localhost", "root", "", "grocery");
    $query = "update tbl_purchase set carrot='$p1',tomato='$p2',cabbage='$p3',betroot='$p4',onion='$p4',apple='$p5',grapes='$p6',orange='$p7',cherry='$p8',mango='$p9',rambuttan='$p10',chicken='$p11',lamp='$p12',prawns='$p13',fish='$p14',crab='$p15' where pid='$id'";
    $re = mysqli_query($con, $query);
    if ($re) {
?>
        <script>
            alert("Order Succussfully Placed ");
            window.location.href = "usergrocery.php";
        </script>
    <?php
    } else {
    ?>
        <script>
            alert("Purchasing failed");
        </script>
<?php
    }
}
?>
<!doctype html>
<html>

<head>
    <title>Online Grocery Shop</title>
    <meta name="Author" content="">
    <meta name="Keywords" content="">
    <meta name="Description" content="">
    <!--font awesome/6 cdn-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <!--external stylesheet-->
    <link rel="stylesheet" href="eatfresh.css" />
    <script>
        function stickyMenu() {
            var sticky = document.getElementById('sticky');
            if (window.pageYOffset > 220) {
                sticky.classList.add('sticky');
            } else {
                sticky.classList.remove('sticky');
            }
        }
        window.onscroll = function() {
            stickyMenu();
        }
    </script>
    <style>
        img {
            border-radius: 50%;
        }
    </style>
    <style>
        .order{
            background-color: gray;
        }
        .one{
            display: inline-block;
            width: 33%;
            height: 300px;
        }
        .two{

            display: inline-block;
            width: 32%;
            height: 300px;
        }
        .three{

            display: inline-block;
            width: 33%;
            height: 300px;
        }
        img {
            border-radius: 50%;
        }
        .pform{
            width: 100%;
        }
    </style>

</head>

<body>
    <?php
    session_start();
    $lid = $_SESSION['id'];
    $con = mysqli_connect("localhost", "root", "", "grocery");
    $query = "select * from tbl_reg where lid='$lid'";
    $re = mysqli_query($con, $query);
    $row = mysqli_fetch_array($re);
    $targetDir = "uploads/";
    $filename = $row["filename"];
    $targetfilepath = $targetDir . $filename;
    ?>
    <div class="parallax">
        <div class="page-title">Eat Fresh</div>
    </div>
    <div class="menu" id="sticky">
        <ul class="menu-ul">
            <a href="usergrocery.php#" class="a-menu">
                <li>Home</li>
            </a>
            <a href="usergrocery.php#deals" class="a-menu">
                <li>Deals</li>
            </a>
            <a href="usergrocery.php#vegetables" class="a-menu">
                <li>Vegetables</li>
            </a>
            <a href="usergrocery.php#fruits" class="a-menu">
                <li>Fruits</li>
            </a>
            <a href="usergrocery.php#meat" class="a-menu">
                <li>Meat</li>
            </a>
            <a href="#" class="a-menu">
                <li>Purchase</li>
            </a>
            <a href="adminpanel.php" class="a-menu">
                <li><img src="images/adminpic (2).png" align="center" width="40">Profile</li>
            </a>
            <a href="logout.php" class="a-menu">
                <li>Log Out</li>
            </a>

            <div class="search-box">
                <form>
                    <input type="text" placeholder="search..." name="search" class="search-input" />
                    <button type="submit"><i class="fa fa-search"></i></button>
                </form>
            </div>
        </ul>
    </div>
    <div class="outer">
        <form action="#" method="POST" class="pform">
        <div class="one">
            <table align="center">
                    <tr>
                        <td>
                            <br><h3>VEGETABLES</h3>
                        </td>
                    </tr>
                    <tr>
                        <td>Carrot:&nbsp;&nbsp;</td>
                        <td><select name="carrot" required class="inputtext">
                                <option value="0g">0g</option>
                                <option value="250g">250g</option>
                                <option value="500g">500g</option>
                                <option value="1000g">1000g</option>
                            </select></td>
                    </tr>
                    <tr>
                        <td>Tomato:&nbsp;&nbsp;</td>
                        <td><select name="tomato" required class="inputtext">
                                <option value="0g">0g</option>
                                <option value="250g">250g</option>
                                <option value="500g">500g</option>
                                <option value="1000g">1000g</option>
                            </select></td>
                    </tr>
                    <tr>
                        <td>Cabbage:&nbsp;&nbsp;</td>
                        <td><select name="cabbage" required class="inputtext">
                                <option value="0g">0g</option>
                                <option value="250g">250g</option>
                                <option value="500g">500g</option>
                                <option value="1000g">1000g</option>
                            </select></td>
                    </tr>
                    <tr>
                        <td>Beetroot:&nbsp;&nbsp;</td>
                        <td><select name="betroot" required class="inputtext">
                                <option value="0g">0g</option>
                                <option value="250g">250g</option>
                                <option value="500g">500g</option>
                                <option value="1000g">1000g</option>
                            </select></td>
                    </tr>
                    <tr>
                        <td>Onion:&nbsp;&nbsp;</td>
                        <td><select name="onion" required class="inputtext">
                                <option value="0g">0g</option>
                                <option value="250g">250g</option>
                                <option value="500g">500g</option>
                                <option value="1000g">1000g</option>
                            </select></td>
                    </tr>
            </table>
                </div>
                <div class="two">
                <table align="center">
                    <tr>
                        <td>
                            <br><h3>FRUITS</h3>
                        </td>
                    </tr>
                    <tr>
                        <td>Apple:&nbsp;&nbsp;</td>
                        <td><select name="apple" required class="inputtext">
                                <option value="0g">0g</option>
                                <option value="250g">250g</option>
                                <option value="500g">500g</option>
                                <option value="1000g">1000g</option>
                            </select></td>
                    </tr>
                    <tr>
                        <td>Grapes:&nbsp;&nbsp;</td>
                        <td><select name="grapes" required class="inputtext">
                                <option value="0g">0g</option>
                                <option value="250g">250g</option>
                                <option value="500g">500g</option>
                                <option value="1000g">1000g</option>
                            </select></td>
                    </tr>
                    <tr>
                        <td>Orange:&nbsp;&nbsp;</td>
                        <td><select name="orange" required class="inputtext">
                                <option value="0g">0g</option>
                                <option value="250g">250g</option>
                                <option value="500g">500g</option>
                                <option value="1000g">1000g</option>
                            </select></td>
                    </tr>
                    <tr>
                        <td>Cherry:&nbsp;&nbsp;</td>
                        <td><select name="cherry" required class="inputtext">
                                <option value="0g">0g</option>
                                <option value="250g">250g</option>
                                <option value="500g">500g</option>
                                <option value="1000g">1000g</option>
                            </select></td>
                    </tr>
                    <tr>
                        <td>Mango:&nbsp;&nbsp;</td>
                        <td><select name="mango" required class="inputtext">
                                <option value="0g">0g</option>
                                <option value="250g">250g</option>
                                <option value="500g">500g</option>
                                <option value="1000g">1000g</option>
                            </select></td>
                    </tr>
                    <tr>
                        <td>Rambuttan:&nbsp;&nbsp;</td>
                        <td><select name="rambuttan" required class="inputtext">
                                <option value="0g">0g</option>
                                <option value="250g">250g</option>
                                <option value="500g">500g</option>
                                <option value="1000g">1000g</option>
                            </select></td>
                    </tr>
                </table>
                </div>
                <div class="three" >
                <table align="center">
                    <tr>
                        <td>
                            <br><h3>MEAT</h3>
                        </td>
                    </tr>
                    <tr>
                        <td>Chicken:&nbsp;&nbsp;</td>
                        <td><select name="chicken" required class="inputtext">
                                <option value="0g">0g</option>
                                <option value="250g">250g</option>
                                <option value="500g">500g</option>
                                <option value="1000g">1000g</option>
                            </select></td>
                    </tr>
                    <tr>
                        <td>Lamb:&nbsp;&nbsp;</td>
                        <td><select name="lamb" required class="inputtext">
                                <option value="0g">0g</option>
                                <option value="250g">250g</option>
                                <option value="500g">500g</option>
                                <option value="1000g">1000g</option>
                            </select></td>
                    </tr>
                    <tr>
                        <td>Prawns:&nbsp;&nbsp;</td>
                        <td><select name="prawns" required class="inputtext">
                                <option value="0g">0g</option>
                                <option value="250g">250g</option>
                                <option value="500g">500g</option>
                                <option value="1000g">1000g</option>
                            </select></td>
                    </tr>
                    <tr>
                        <td>Fish:&nbsp;&nbsp;</td>
                        <td><select name="fish" required class="inputtext">
                                <option value="0g">0g</option>
                                <option value="250g">250g</option>
                                <option value="500g">500g</option>
                                <option value="1000g">1000g</option>
                            </select></td>
                    </tr>
                    <tr>
                        <td>Crab:&nbsp;&nbsp;</td>
                        <td><select name="crab" required class="inputtext">
                                <option value="0g">0g</option>
                                <option value="250g">250g</option>
                                <option value="500g">500g</option>
                                <option value="1000g">1000g</option>
                            </select></td>
                    </tr>
                </table>
                </div>
    </div>
    <div class="submit">
    <table align="center">
        <tr>
            <td colspan='2'><br><br><input type="submit" id="submit" value="Place order" name="sub"></td>
        </tr>
    </table>
    </div>
    </form>
        <br>
        <h2 align="center">Show Purchase details ?&nbsp;&nbsp;<a href="purchasedetails.php">Click Here</a></h2>
    </div>
    <div>


    </div>
    <?php
    mysqli_close($con);
    ?>
    </div>
    <!--- <h2 align="center">&nbsp;&nbsp;<a href="logout.php">Log Out</a></h2><br>--->
    </div><br><br>
    <!---Footer starts here-->
    <div class="parallax1">
        <div class="footer">
            <div class="quick-links">
                <div>Stores</div>
                <ul>
                    <li><a href="https://goo.gl/maps/rFauva4Ncj6HVmqN8" class="a-links">Puthuparambil stores</a>
                    <li>
                    <li><a href="https://goo.gl/maps/v7GPeRDVoUVXmxSYA" class="a-links">More Supermarket</a>
                    <li>
                    <li><a href="https://goo.gl/maps/7VqVW2X5uxdH5aDn7" class="a-links">Real Hyper Market</a>
                    <li>
                </ul>
            </div>

            <div class="quick-links">
                <div>Careers</div>
                <ul>
                    <li><a href="" class="a-links">Packing</a>
                    <li>
                    <li><a href="" class="a-links">Staffing</a>
                    <li>
                    <li><a href="" class="a-links">Delivery Agent</a>
                    <li>
                </ul>
            </div>
            <div class="quick-links">
                <div>Quick Links</div>
                <ul>
                    <li><a href="" class="a-links">Contact us</a>
                    <li>
                    <li><a href="" class="a-links">FAQ</a>
                    <li>
                    <li><a href="" class="a-links">Help</a>
                    <li>
                </ul>
            </div>
        </div>
    </div>
    <div class="Copyrights">
        <i class="fast fa=copyright fa-1x">@2022 By Wilgimol Thomas</i>
    </div>

    <!---Footer Ends here-->
</body>

</html>