<?php
$id = $_GET['id'];
$con = mysqli_connect("localhost", "root", "", "grocery");
$query1 = "update tbl_login set admin=1 where lid='$id'";
$re1 = mysqli_query($con, $query1);
if ($re1) {

    $query2 = "update tbl_reg set admin=1 where lid='$id'";
    $re2 = mysqli_query($con, $query2);
    if($re2){
        ?>
    <script>
        alert("User upgraded to admin");
        window.location.href = "userdetails.php";
    </script>
<?php
}
}
mysqli_close($con);
?>