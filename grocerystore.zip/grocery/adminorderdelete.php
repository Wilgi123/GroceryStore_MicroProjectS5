<!----Delete Order----->
<?php
        $id=$_GET['id'];
		$con=mysqli_connect("localhost","root","","grocery");
		$query="delete from tbl_orderd where oid='$id'";
		$re=mysqli_query($con,$query);
        if($re)
        {
            $q="delete from tbl_order where oid='$id'";
		    $re1=mysqli_query($con,$q);
            if($re1){
            ?>
                <script>
                    alert("Order Cancelled");
                    window.location.href = "userorderdetails.php";
                </script>
            <?php
        }
        }
		mysqli_close($con);
	
?>