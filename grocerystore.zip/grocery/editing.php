<!---Profile Updation ---->
<?php
session_start();
$lid = $_SESSION['id'];
$con = mysqli_connect("localhost", "root", "", "grocery");
$query1 = "select *from tbl_reg where lid='$lid'";
$re1 = mysqli_query($con, $query1);
$row1 = mysqli_fetch_array($re1);
$na = $row1['name'];
$ma = $row1['email'];
$ph = $row1['phone'];
if (isset($_POST['submit'])) {
	$na = $_POST['name'];
	$ma = $_POST['email'];
	$ph = $_POST['phone'];
	$filename = $_FILES["photo"]["name"];
	$q = "update tbl_reg set name='$na',email='$ma',phone='$ph',filename='$filename' where lid='$lid'";
	$res = mysqli_query($con, $q);
	if ($res) {
		$targetDir = "uploads/";
		$targetfilepath = $targetDir . $filename;
		move_uploaded_file($_FILES["photo"]["tmp_name"], $targetfilepath);
?>
		<script>
			alert("updation successful");
			window.location.href = "userpanal.php";
		</script>
	<?php
	} else {
	?>
		<script>
			alert("updation failed");
		</script>
<?php
	}
	mysqli_close($con);
}
?>
<!DOCTYPE html>

<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<title>Update Form</title>
</head>
<style>
	.error {
		color: #cc0033;
		font-family: Helvetica, Arial, sans-serif;
		font-size: 13px;
		font-weight: bold;
		line-height: 20px;
		text-shadow: 1px 1px rgba(250, 250, 250, .3);
	}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
	$(document).ready(function() {
		$("#error1").hide();
		$("#error3").hide();
		$("#error7").hide();
		$("#error6").hide();
		var name = /^[a-zA-Z ]{3,16}$/;
		$("#p1").keyup(function() {
			x = document.getElementById("p1").value;
			if (name.test(x) == false) {
				ver1 = 1
				$("#error1").show();
			} else if (name.test(x) == true) {
				ver1 = 0;
				$("#error1").hide();
			}
		});
		var ph = /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[789]\d{9}$/;
		$("#p7").keyup(function() {
			x = document.getElementById("p7").value;
			if (ph.test(x) == false) {
				ver2 = 1
				$("#error7").show();
			} else if (ph.test(x) == true) {
				ver2 = 0;
				$("#error7").hide();
			}
		});
		var mail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{3,4})+$/;
		$("#p3").keyup(function() {
			x = document.getElementById("p3").value;
			if (mail.test(x) == false) {
				ver4 = 1;
				$("#error3").show();
			} else if (mail.test(x) == true) {
				ver4 = 0;
				$("#error3").hide();
			}
		});
		$("#submit").click(function() {
			if (ver1 == 0 && ver2 == 0 && ver4 == 0) {
				$("#error6").hide();
				return true;
			} else {
				$("#error6").show();
				return false;
			}
		});
	});
</script>

<body>
	<div class="container">
		<form action="#" method="POST" class="login-email" enctype="multipart/form-data">
			<p class="login-text" style="font-size: 2rem; font-weight: 800;">Update details</p>
			<div class="input-group">
				<input type="text" id="p1" placeholder="Name" name="name" value="<?php echo $na; ?>" required>
			</div>
			<p id="error1" class="error">&nbsp;Only alphabets are allowed</p><br>
			<div class="input-group">
				<input type="text" id="p7" class="inputtext" placeholder="Enter phone number" name="phone" value="<?php echo $ph; ?>" required>
			</div>
			<p id="error7" class="error">&nbsp;Enter a valid number</p><br>
			<div class="input-group">
				<input type="file" accept="image/png, image/gif, image/jpeg" placeholder="Profile Photo" name="photo" required>
			</div>
			<div class="input-group">
				<input type="text" id="p3" placeholder="Email" name="email" value="<?php echo $ma; ?>" required>
			</div>
			<p id="error3" class="error">&nbsp;Use a valid email address</p><br>
			<p id="error6" class="error">&nbsp;Please fill the form correctly.</p><br>
			<div class="input-group">
				<input type="submit" id="submit" name="submit" class="btn" value="Register">
			</div>
		</form>
	</div>
</body>

</html>