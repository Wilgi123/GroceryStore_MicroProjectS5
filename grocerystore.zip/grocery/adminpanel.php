<!---User Profile page---->
<?php
session_start();
if (isset($_SESSION['ad'])) {
?>
	<!doctype html>
	<html>

	<head>
		<title>Online Grocery Shop</title>
		<meta name="Author" content="">
		<meta name="Keywords" content="">
		<meta name="Description" content="">
		<!--font awesome/6 cdn-->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
		<!--external stylesheet-->
		<link rel="stylesheet" href="eatfresh.css" />
		<!--<script type="text/javascript">
			function preventBack() {
				window.history.forward();
			}
			setTimeout("preventBack()", 0);
			window.onunload = function() {
				null
			};
		</script>-->
		<style>
			.styled-table {
				border-collapse: collapse;
				margin: 25px 0;
				font-size: 1em;
				font-family: sans-serif;
				min-width: 400px;
				box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);

			}

			.styled-table th,
			.styled-table td {
				padding: 9px 12px;
			}

			.styled-table tr {
				border-bottom: 1px solid #dddddd;
			}

			.styled-table tr:nth-of-type(even) {
				background-color: #f3f3f3;
			}

			.styled-table tr:last-of-type {
				border-bottom: 2px solid #009879;
			}

			.styled-table tr:first-of-type {
				border-top: 2px solid #009879;
			}

			.styled-table th {
				font-size: 14px;
				font-weight: bold;
				color: #009879;
			}
		</style>

		<script>
			function stickyMenu() {
				var sticky = document.getElementById('sticky');
				if (window.pageYOffset > 220) {
					sticky.classList.add('sticky');
				} else {
					sticky.classList.remove('sticky');
				}
			}
			window.onscroll = function() {
				stickyMenu();
			}
		</script>
		<style>
			img {
				border-radius: 50%;
			}
		</style>
	</head>

	<body>
		<div class="parallax">
			<div class="page-title">Eat Fresh</div>
		</div>
		<div class="menu" id="sticky">
			<ul class="menu-ul">
				<a href="adminpanel.php#" class="a-menu">
					<li>Home</li>
				</a>
				<a href="product.php" class="a-menu">
					<li>Products</li>
				</a>
				<a href="userdetails.php" class="a-menu">
					<li>Users</li>
				</a>
				<a href="logout.php" class="a-menu">
					<li>log Out</li>
				</a>
			</ul>
		</div>
		<br><br>
       <p style=" font-family: 'Times New Roman', Times, serif;font-size: 22px;" align="center"><b> ‘Eat Fresh’</b>

Spare more with <b>‘Eat Fresh!'</b> We give you the most minimal costs on the entirety of your grocery needs.

<b>‘Eat Fresh’</b> is a low-cost online general store that gets items crosswise over classifications like grocery, natural products and vegetables, excellence and health, family unit care, infant care, pet consideration, and meats and fish conveyed to your doorstep.

Browse more than 5,000 items at costs lower than markets each day!

Calendar conveyance according to your benefit.

Level 20% cashback on your first request with coupon code<b> ‘Eat Fresh’</b> 20. Max cashback is Rs.250.</p>


		</div>
		<!--- <h2 align="center">&nbsp;&nbsp;<a href="logout.php">Log Out</a></h2><br>--->
		</div><br><br>
		<!---Footer starts here-->
		<div class="parallax1">
			<div class="footer">
				<div class="quick-links">
					<div>Stores</div>
					<ul>
						<li><a href="https://goo.gl/maps/rFauva4Ncj6HVmqN8" class="a-links">Puthuparambil stores</a>
						<li>
						<li><a href="https://goo.gl/maps/v7GPeRDVoUVXmxSYA" class="a-links">More Supermarket</a>
						<li>
						<li><a href="https://goo.gl/maps/7VqVW2X5uxdH5aDn7" class="a-links">Real Hyper Market</a>
						<li>
					</ul>
				</div>

				<div class="quick-links">
					<div>Careers</div>
					<ul>
						<li><a href="" class="a-links">Packing</a>
						<li>
						<li><a href="" class="a-links">Staffing</a>
						<li>
						<li><a href="" class="a-links">Delivery Agent</a>
						<li>
					</ul>
				</div>
				<div class="quick-links">
					<div>Quick Links</div>
					<ul>
						<li><a href="" class="a-links">Contact us</a>
						<li>
						<li><a href="" class="a-links">FAQ</a>
						<li>
						<li><a href="" class="a-links">Help</a>
						<li>
					</ul>
				</div>
			</div>
		</div>
		<div class="Copyrights">
			<i class="fast fa=copyright fa-1x">@2022 By Wilgimol Thomas</i>
		</div>

		<!---Footer Ends here-->
	</body>

	</html>
<?php
} else {
	header('Location: grocery.php');
}
?>