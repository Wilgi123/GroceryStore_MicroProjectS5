<!---Main Availabilty---->
<?php
$con = mysqli_connect("localhost", "root", "", "grocery");
if (isset($_POST['email']) && $_POST['email'] != "") {
    if ($stmt = $con->prepare("SELECT email FROM tbl_reg WHERE email = ?")) {
        $stmt->bind_param('s', $_POST['email']);
        $stmt->execute();
        $stmt->store_result();
        $numRows = $stmt->num_rows;
        if ($numRows > 0) {
            echo "<span class='er1'> &nbsp;Mail id Not Available.</span>
            <script>var ver8=1;</script>";
        } else {
            echo "<span class='er2'> &nbsp;Mail id Available.</span>
            <script>var ver8=0;</script>";
        }
    }
}
$con->close();
ob_end_flush();
?>
<html>

<head>
    <style>
        .er2 {

            color: #00FF00;
            font-family: Helvetica, Arial, sans-serif;
            font-size: 13px;
            font-weight: bold;
            line-height: 20px;
            text-shadow: 1px 1px rgba(250, 250, 250, .3);
        }

        .er1 {
            color: #cc0033;
            font-family: Helvetica, Arial, sans-serif;
            font-size: 13px;
            font-weight: bold;
            line-height: 20px;
            text-shadow: 1px 1px rgba(250, 250, 250, .3);
        }
    </style>
</head>

<body>
</body>

</html>