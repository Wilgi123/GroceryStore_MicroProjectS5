<!doctype html>
 <head>
  <title>Submition</title>
 <!--font awesome/6 cdn-->
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
 <!--external stylesheet-->
 <link rel="stylesheet" href="eatfresh.css"/>
 </head>
 <body id="back">
    <div class="parallax2">
      <div class="page-title">You Have Successfully Submitted Your Feedback<br>Thank You For Visiting Our Website </div>
   </div>
 </body>
</html>