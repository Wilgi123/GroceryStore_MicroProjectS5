<!----Delete Items From Kart---->
<?php
        $id=$_GET['prid'];
		$con=mysqli_connect("localhost","root","","grocery");
		$query="delete from tbl_product where prid='$id'";
		$re=mysqli_query($con,$query);
        if($re)
        {
            ?>
                <script>
                    alert("product removed");
                    window.location.href = "product.php";
                </script>
            <?php
        }
		mysqli_close($con);
	
?>