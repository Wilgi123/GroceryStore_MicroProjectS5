<!----Kart Function----->
<?php
		session_start();
		$lid=$_SESSION['id'];
        $prid=$_GET['prid'];
		$con=mysqli_connect("localhost","root","","grocery");
		$q1="select * from tbl_product where prid='$prid'";
		$re1=mysqli_query($con,$q1);
		$row1=mysqli_fetch_array($re1);
		$na=$row1['name'];
		$pr=$row1['price'];
		$ty=$row1['type'];
		$qty=$row1['qty'];
		if($qty<=0)
		{
			?>
                <script>
					alert("Product is out of stock");
                    window.location.href = "usergrocery.php";
                </script>
            <?php
		}
		else
		{
		$query="insert into tbl_cart(prid,lid,name,price,type) values('$prid','$lid','$na','$pr','$ty')";
		$re=mysqli_query($con,$query);
        if($re)
        {
            ?>
                <script>
                    window.location.href = "usergrocery.php";
                </script>
            <?php
        }
		}
?>