<!---User Profile page---->
<?php
session_start();
if (isset($_SESSION['ad'])) {
?>
	<!doctype html>
	<html>

	<head>
		<title>Online Grocery Shop</title>
		<meta name="Author" content="">
		<meta name="Keywords" content="">
		<meta name="Description" content="">
		<!--font awesome/6 cdn-->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
		<!--external stylesheet-->
		<link rel="stylesheet" href="eatfresh.css" />
		<!--<script type="text/javascript">
			function preventBack() {
				window.history.forward();
			}
			setTimeout("preventBack()", 0);
			window.onunload = function() {
				null
			};
		</script>-->
		<style>
			.styled-table {
				border-collapse: collapse;
				margin: 25px 0;
				font-size: 1em;
				font-family: sans-serif;
				min-width: 400px;
				box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);

			}

			.styled-table th,
			.styled-table td {
				padding: 9px 12px;
			}

			.styled-table tr {
				border-bottom: 1px solid #dddddd;
			}

			.styled-table tr:nth-of-type(even) {
				background-color: #f3f3f3;
			}

			.styled-table tr:last-of-type {
				border-bottom: 2px solid #009879;
			}

			.styled-table tr:first-of-type {
				border-top: 2px solid #009879;
			}

			.styled-table th {
				font-size: 14px;
				font-weight: bold;
				color: #009879;
			}
		</style>

		<script>
			function stickyMenu() {
				var sticky = document.getElementById('sticky');
				if (window.pageYOffset > 220) {
					sticky.classList.add('sticky');
				} else {
					sticky.classList.remove('sticky');
				}
			}
			window.onscroll = function() {
				stickyMenu();
			}
		</script>
		<style>
			img {
				border-radius: 50%;
			}
		</style>
	</head>

	<body>
			
        <?php
    $con = mysqli_connect("localhost", "root", "", "grocery");
    $query = "select * from tbl_reg;";
    $re = mysqli_query($con, $query);
    ?>
   <div class="parallax">
			<div class="page-title">Eat Fresh</div>
		</div>
		<div class="menu" id="sticky">
			<ul class="menu-ul">
				<a href="adminpanel.php" class="a-menu">
					<li>Home</li>
				</a>
				<a href="productinsert.php" class="a-menu">
					<li>Products</li>
				</a>
				<a href="userdetails.php" class="a-menu">
					<li>User</li>
				</a>
				<a href="logout.php" class="a-menu">
					<li>Log Out</li>
				</a>
			</ul>
		</div>
		<br><br>
		<div align="center">
        <table width="900" class="styled-table">
				<tr>
                    <th>Si.No</th>
                    <th>Name</th>
                    <th>Phone no</th>
                    <th>Email</th>
                    <th colspan='3'>Action</th>
                </tr>
                <?php
                $cid = 0;
                while ($row = mysqli_fetch_array($re)) {
                    $cid++;
				echo "<tr><td>", $cid,
                     "</td><td>", $row['name'],
                     "</td><td>", $row['phone'],
                     "</td><td>", $row['email'],
                     "</td><td><a href='userdelete.php?id=", $row['lid'], "'>Delete</a></td><td><a href='useradmin.php?id=", $row['lid'], "'>Make admin</a></td><td>
                     <a href='userorderdetails.php?id=", $row['lid'], "'>View Orders</a></td></tr>";
                }
                ?>
            </table>
        </div>
        <?php
        mysqli_close($con);
        ?>
</div>
		<!--- <h2 align="center">&nbsp;&nbsp;<a href="logout.php">Log Out</a></h2><br>--->
		</div><br><br>
		<!---Footer starts here-->
		<div class="parallax1">
			<div class="footer">
				<div class="quick-links">
					<div>Stores</div>
					<ul>
						<li><a href="https://goo.gl/maps/rFauva4Ncj6HVmqN8" class="a-links">Puthuparambil stores</a>
						<li>
						<li><a href="https://goo.gl/maps/v7GPeRDVoUVXmxSYA" class="a-links">More Supermarket</a>
						<li>
						<li><a href="https://goo.gl/maps/7VqVW2X5uxdH5aDn7" class="a-links">Real Hyper Market</a>
						<li>
					</ul>
				</div>

				<div class="quick-links">
					<div>Careers</div>
					<ul>
						<li><a href="" class="a-links">Packing</a>
						<li>
						<li><a href="" class="a-links">Staffing</a>
						<li>
						<li><a href="" class="a-links">Delivery Agent</a>
						<li>
					</ul>
				</div>
				<div class="quick-links">
					<div>Quick Links</div>
					<ul>
						<li><a href="" class="a-links">Contact us</a>
						<li>
						<li><a href="" class="a-links">FAQ</a>
						<li>
						<li><a href="" class="a-links">Help</a>
						<li>
					</ul>
				</div>
			</div>
		</div>
		<div class="Copyrights">
			<i class="fast fa=copyright fa-1x">@2022 By Wilgimol Thomas</i>
		</div>

		<!---Footer Ends here-->
	</body>

	</html>
<?php
} else {
	header('Location: grocery.php');
}
?>
		