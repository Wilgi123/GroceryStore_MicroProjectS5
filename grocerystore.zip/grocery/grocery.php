<!---Main Grocery page---->
<!doctype html>
<html>

<head>
	<?php
	$con=mysqli_connect("localhost","root","","grocery");
	?>
	<title>Online Grocery Shop</title>
	<meta name="Author" content="">
	<meta name="Keywords" content="">
	<meta name="Description" content="">
	<!--font awesome/6 cdn-->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
	<!--external stylesheet-->
	<link rel="stylesheet" href="eatfresh.css" />
	<script>
		function stickyMenu() {
			var sticky = document.getElementById('sticky');
			if (window.pageYOffset > 220) {
				sticky.classList.add('sticky');
			} else {
				sticky.classList.remove('sticky');
			}
		}
		window.onscroll = function() {
			stickyMenu();
		}
	</script>
</head>

<body>
	<div class="parallax">
		<div class="page-title">Eat Fresh</div>
	</div>
	<div class="menu" id="sticky">
		<ul class="menu-ul">
			<a href="#" class="a-menu">
				<li>Home</li>
			</a>
			<a href="#deals" class="a-menu">
				<li>Deals</li>
			</a>
			<a href="#vegetables" class="a-menu">
				<li>Vegetables</li>
			</a>
			<a href="#fruits" class="a-menu">
				<li>Fruits</li>
			</a>
			<a href="#meat" class="a-menu">
				<li>Meat</li>
			</a>
			<a href="login.php" class="a-menu">
				<li>Login</li>
			</a>
			<a href="register.php" class="a-menu">
				<li>Register</li>
			</a>

			<!--- <div class="search-box">
	    <form>
		  <input type="text" placeholder="search..." name="search"
		         class="search-input"/>
		  <button type="submit"><i class="fa fa-search"></i></button>
		</form>
     </div>---->
		</ul>
	</div>
	<!--Home Page Begins-->
	<div class="container">
		<a href="#vegetables">
			<div class="categories">
				<img src="images/veg/greenpepper.jpg" class="item-image" />
				<div class="image-title">Vegetables</div>
			</div>
		</a>
		<a href="#fruits">
			<div class="categories">
				<img src="images/fru/strawberry.jpg" class="item-image" />
				<div class="image-title">Fruits</div>
			</div>
		</a>
		<a href="#meat">
			<div class="categories">
				<img src="images/meat/chicken.jpg" class="item-image" />
				<div class="image-title">Meat & Seafood</div>
			</div>
		</a>
		<a href="#deals">
			<div class="categories">
				<img src="images/deals.jpg" class="item-image" />
				<div class="image-title">Deals</div>
			</div>
		</a>
	</div>
	<!--Deal Begins Here --->
	<div class="deals-container" id="deals">
		<div class="parallax">
			<div class="title">Deals</div>
		</div>
		<div class="deal"><b id="size">20% </b>off
			<hr></br>
			On min-purchase of Rs 300 on vegetables</br>
			<button class="coupon-btn">Add Coupons</button>
		</div>
		<div class="deal"><b id="size">10% </b>off
			<hr></br>
			On min-purchase of Rs 200 on fruits</br>
			<button class="coupon-btn">Add Coupons</button>
		</div>
		<div class="deal"><b id="size">15% </b>off
			<hr></br>
			On min-purchase of Rs 500 on meat/seafood</br>
			<button class="coupon-btn">Add Coupons</button>
		</div>
	</div>
	<!--Deal Ends Here --->

	<!--Veg Begins Here --->
	<div class="deals-container" id="vegetables">
		<div class="parallax">
			<div class="title">Vegetables</div>
		</div>
		<?php
		$query1="select * from tbl_product where type='veg';";
		$re1=mysqli_query($con,$query1);
		while($row=mysqli_fetch_array($re1))
		{
			echo"
			<div class='items'>
			<div class='images'>
				<img src='images/veg/",$row['image'],"' class='item-image-size'/>
			</div>
			<div class='description'>
				<b>",$row['name'],"</b>
				<div class='item-select'>
					price:",$row['price'],"/kg
				</div>
				</select></br>
				<button class='buynow-btn'>Buy Now</button>
			</div>
		</div>
		";
		}
		?>
		</div>
	<!--Veg Ends Here --->

	<!--Fruits Begins Here --->
	<div class="deals-container" id="fruits">
		<div class="parallax">
			<div class="title">Fruits</div>
		</div>
		<?php
		$query2="select * from tbl_product where type='fru';";
		$re2=mysqli_query($con,$query2);
		while($row1=mysqli_fetch_array($re2))
		{
			echo"
			<div class='items'>
			<div class='images'>
				<img src='images/fru/",$row1['image'],"' class='item-image-size'/>
			</div>
			<div class='description'>
				<b>",$row1['name'],"</b>
				<div class='item-select'>
					price:",$row1['price'],"/kg
				</div>
				</select></br>
				<button class='buynow-btn'>Buy Now</button>
			</div>
		</div>
		";
		}
		?>
		</div>
	<!--Fruits Ends Here --->

	<!--Meat Begins Here --->
	<div class="deals-container" id="meat">
			<div class="parallax1">
				<div class="title">Meat & Seafood</div>
			</div>
			<?php
			$query3="select * from tbl_product where type='meat';";
			$re3=mysqli_query($con,$query3);
			while($row2=mysqli_fetch_array($re3))
			{
				echo"
				<div class='items'>
				<div class='images'>
					<img src='images/meat/",$row2['image'],"' class='item-image-size'/>
				</div>
				<div class='description'>
					<b>",$row2['name'],"</b>
					<div class='item-select'>
						price:",$row2['price'],"/kg
					</div>
					</select></br>
					<button class='buynow-btn'>Buy Now</button>
				</div>
			</div>
			";
			}
			?>
			</div>
		<!--Meat Ends Here --->
			<!--Home Page Ends-->

			<!---Footer starts here-->
			<div class="parallax1">
				<div class="footer">
					<div class="quick-links">
						<div>Stores</div>
						<ul>
							<li><a href="https://goo.gl/maps/rFauva4Ncj6HVmqN8" class="a-links">Puthuparambil stores</a>
							<li>
							<li><a href="https://goo.gl/maps/v7GPeRDVoUVXmxSYA" class="a-links">More Supermarket</a>
							<li>
							<li><a href="https://goo.gl/maps/7VqVW2X5uxdH5aDn7" class="a-links">Real Hyper Market</a>
							<li>
						</ul>
					</div>

					<div class="quick-links">
						<div>Careers</div>
						<ul>
							<li><a href="" class="a-links">Packing</a>
							<li>
							<li><a href="" class="a-links">Staffing</a>
							<li>
							<li><a href="" class="a-links">Delivery Agent</a>
							<li>
						</ul>
					</div>
					<div class="quick-links">
						<div>Quick Links</div>
						<ul>
							<li><a href="" class="a-links">Contact us</a>
							<li>
							<li><a href="" class="a-links">FAQ</a>
							<li>
							<li><a href="" class="a-links">Help</a>
							<li>
						</ul>
					</div>
				</div>
			</div>
			<div class="Copyrights">
				<i class="fast fa=copyright fa-1x">@2022 By Wilgimol Thomas</i>
			</div>

			<!---Footer Ends here-->
</body>

</html>