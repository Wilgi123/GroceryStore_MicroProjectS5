<!---Login page---->
<?php
	if(isset($_POST['submit']))
	{
		$un=$_POST['username'];
		$ps=$_POST['password'];
		session_start();
		$con=mysqli_connect("localhost","root","","grocery");
		$query="select * from tbl_login where username='$un' and password='$ps'";
		$re=mysqli_query($con,$query);
		$row=mysqli_fetch_array($re);
        $admin = $row['admin'];
		if ($admin == 1) {
            header('Location:adminpanel.php');
            $_SESSION['ad'] = 1;
        } else {
            $count = mysqli_num_rows($re);
            if ($count > 0) {
                $_SESSION['id'] = $row['lid'];
    ?>
                <script>
                    alert("Login successful");
                </script>
            <?php
                header('Location: usergrocery.php');
            } else {
            ?>
                <script>
                    alert("Username and password does not match");
                    window.location.href="login.php";
                </script>
    <?php
            }
        }
        mysqli_close($con);
    }
    ?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
	<link rel="stylesheet" type="text/css" href="style.css">

	<title>Login Form</title>
</head>
<style>
#error2,#error3, #error5
 {
  color: #cc0033;
  font-family: Helvetica, Arial, sans-serif;
  font-size: 13px; 
  font-weight: bold;
  line-height: 20px;
  text-shadow: 1px 1px rgba(250,250,250,.3);  
 }
 .password-container{
  width: 100%;
  position: relative;
}
input, input[type=password]
        {
            width: 150px;
            height: 20px;
        }
.fa-eye{
  position: absolute;
  top: 28%;
  right: 4%;
  cursor: pointer;
  color: lightgray;
}
#toggle_pwd
        {
            cursor: pointer;
        }
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <script>
        var ver1 = 1;
        var ver2 = 1;
        $(document).ready(function () {
            $("#error2").hide();
			$("#error3").hide();
            $("#error5").hide();
            var uname = /^[a-zA-Z0-9\-\_]+$/;
            $("#p2").keyup(function () {
                x = document.getElementById("p2").value;
                if (uname.test(x) == false) {
                    ver1 = 1;
                    $("#error2").show();
                }
                else if (uname.test(x) == true) {
                    ver1 = 0;
                    $("#error2").hide();
                }
            });
           /* var pass = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
            $("#p3").keyup(function () {
                x = document.getElementById("p3").value;
                if (pass.test(x) == false) {
                    ver2 = 1;
                    $("#error3").show();
                }
                else if (pass.test(x) == true) {
                    ver2 = 0;
                    $("#error3").hide();
                }
            });*/
			
            $("#submit").focus(function () {
                if (ver1 == 0  && ver2==0)
                    $("#error5").hide();
                else
                    $("#error5").show();
            });
        });
    </script>
<body>
	<div class="container">
		<form action="#" method="POST" class="login-email">
			<p class="login-text" style="font-size: 2rem; font-weight: 800;">Login</p>
			<div class="input-group">
				<input type="text" id="p2" placeholder="Username" name="username"required>
			</div>
			<p id="error2">&nbsp;Enter a valid username</p><br>
			<div class="input-group">
			<div class="password-container">
				<input type="password" id="p3" placeholder="Password" name="password" required>
				<i class="fa fa-fw fa-eye field_icon" id="toggle_pwd" style="margin-left: -30px; cursor: pointer;"></i>
                <script type="text/javascript">
                    const togglePassword = document.querySelector('#toggle_pwd');
                    const password = document.querySelector('#p3');
                    togglePassword.addEventListener('click', function (e) {
                    // toggle the type attribute
                    const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
                    password.setAttribute('type', type);
                    // toggle the eye slash icon
                    this.classList.toggle('fa-eye-slash');
                    });
                </script>
            </div>
	        </div>
			<p id="error3">&nbsp;Enter a valid password</p><br>
			<p id="error5">&nbsp;Please fill the form correctly.</p><br>
			<div class="input-group">
				<input type="submit" name="submit" value="Login" class="btn">
			</div>
			<p class="login-register-text">Don't have an account? <a href="register.php">Register Here</a>.</p>
		</form>
	</div>
</body>
</html>
