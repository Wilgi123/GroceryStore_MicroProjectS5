<!----Delete Items From Kart---->
<?php
        $id=$_GET['id'];
		$con=mysqli_connect("localhost","root","","grocery");
		$query="delete from tbl_cart where kid='$id'";
		$re=mysqli_query($con,$query);
        if($re)
        {
            ?>
                <script>
                    alert("Item removed");
                    window.location.href = "purchasedetails.php";
                </script>
            <?php
        }
		mysqli_close($con);
	
?>