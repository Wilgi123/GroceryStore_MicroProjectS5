<?php
        $id=$_GET['id'];
		$con=mysqli_connect("localhost","root","","projectdb");
		$query="delete from tbl_book where bid='$id'";
		$re=mysqli_query($con,$query);
        if($re)
        {
            ?>
                <script>
                    alert("Reservation successfully deleted");
                    window.location.href = "bookingdetails.php";
                </script>
            <?php
        }
		mysqli_close($con);
	
?>