<?php
if(isset($_POST['sub']))
{
            $id=$_GET['id'];
            $na=$_POST['name'];
            $ma=$_POST['mail'];
            $da=$_POST['date'];
            $no=$_POST['people'];
            $ro=$_POST['room'];
			$con=mysqli_connect("localhost","root","","projectdb");
			$query="update tbl_book set name='$na',email='$ma',date='$da',people='$no',room='$ro' where bid='$id'";
			$re=mysqli_query($con,$query);
            if($re)
			{
				?>
				<script>
					alert("Reservation successfully edited");
                    window.location.href = "bookingdetails.php";
				</script>
				<?php
			}
			else
			{
			?>
				<script>
					alert("Reservation failed");
				</script>
			<?php
			}
}
?>
<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title>Sapphire</title>
    <link rel="icon" href="assets/logo1.png">
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cabin&family=Lobster&display=swap" rel="stylesheet">
<style>
    @import url('https://fonts.googleapis.com/css2?family=Lobster&display=swap');
    </style>
</head>
<body>
<div class="header">
    <div class="headdiv">
        <div class="logoimg">
            <img src="assets/logo1.png" />
        </div>
    </div>
    <div class="headdiv1">
        <div class="hheading">
            <p id="heading">Sapphire</p>
        </div>
        <div class="hlinkdiv">
                <a class="hlink" href="usermenu.php">Home</a>&nbsp;&nbsp;
                <a class="hlink" href="usergallery.php#gal">Gallery</a>&nbsp;&nbsp;
                <a class="hlink" href="user.php">Profile</a>&nbsp;&nbsp;
                <a class="hlink" href="logout.php">Logout</a>&nbsp;&nbsp;
            </div>
    </div>
</div>
<br><br>
<div class="sectionb" id="contact" >
    <h3 style="font-size: 40px;color: rgb(0, 0, 0); margin-left: 45px;" align="center">Room Reservation</h3>
    <div class="inputdiv">
        <form action="#" method="POST">
            <table>
                <tr>
                    <td>Name:&nbsp;&nbsp;</td>
                    <td><input type="text" class="inputtext" name="name" placeholder="Enter Name" required style="width:220%;"></td>
                </tr>
                <tr>
                    <td>Email Id:&nbsp;&nbsp;</td>
                    <td><input type="email" class="inputtext" name="mail" placeholder="Enter Email Address" required style="width:220% ;"></td>
                </tr>
                <tr>
                    <td>Checkin Date:&nbsp;&nbsp;</td>
                    <td><input type="date" class="inputtext" name="date" placeholder="Date for Reservation" required style="width:220% ;"></td>
                </tr>
                <tr>
                    <td>Number of People:&nbsp;&nbsp;</td>
                    <td><input type="number" class="inputtext" name="people" placeholder="How Many People" required style="width:220% ;"></td>
                </tr>
                <tr>
                    <td>Select room:&nbsp;&nbsp;</td>
                    <td><select name="room" required name="room" class="inputtext" style="width:220% ;">
                    <option value="Single Suite">Single Suite</option>
                    <option value="Double Suite">Double Suite</option>
                    <option value="Honeymoon Suite">Honeymoon Suite</option>
                    <option value="Luxury Suite">Luxury Suite</option>
                    </select></td>
                </tr>
            </table>
            <br><br>
            <div align="center">
                    <input type="submit" id="submit" class="inputbutton" value="Save changes" name="sub">
            </div>
        </form> 
    </div>
</div>
<br><h2 align="center">Show booking details?&nbsp;&nbsp;<a href="bookingdetails.php">Show details</a></h2><br>
<div class="footer">
    <div class="footer_logo">
        <a href="usermenu.php"><img src="assets/logo1.png" style="margin-left: 7%;width:200px;height: 200px;"></a><br>
    </div>
    <div class="footer_space">
        <div class="footer_social">
            <a href="https://instagram.com/"><img src="assets/images/insta.png"></a>
        </div>
        <div class="footer_social">
            <a href="https://www.facebook.com/"><img src="assets/images/facebook.png"></a>
        </div>
        <div class="footer_social">
            <a href="https://mail.google.com/mail/u/0/"><img src="assets/images/email.png"></a>
        </div>
        <div class="footer_location">
            <img src="assets/images/location.png"><br>
            <div><span>Paradise Islands<br>Maldives</span></div>
        </div>
        <div class="footer_info">
            <span>An award-winning beachfront property near Male Airport,Sapphire Resort & Spa is known for its 6 dining options,Araamu Spa and activities.</span>
        </div>
    </div>
</div>
</body>
</html>

