<!---Username availability checking---->
<?php
$con = mysqli_connect("localhost", "root", "", "grocery");

if (isset($_POST['uname']) && $_POST['uname'] != "") {
    if ($stmt = $con->prepare("SELECT username FROM tbl_login WHERE username = ?")) {
        $stmt->bind_param('s', $_POST['uname']);
        $stmt->execute();
        $stmt->store_result();
        $numRows = $stmt->num_rows;
        if ($numRows > 0) {
            echo "<span class='er1'>&nbsp;Username Not Available.</span>
             <script> var ver7=1;</script>";
        } else {
            echo "<span class='er2'>&nbsp;Username Available.</span>
             <script> var ver7=0;</script>";
        }
    }
}
$con->close();
ob_end_flush();
?>
<html>

<head>
    <style>
        .er2 {

            color: #00FF00;
            font-family: Helvetica, Arial, sans-serif;
            font-size: 13px;
            font-weight: bold;
            line-height: 20px;
            text-shadow: 1px 1px rgba(250, 250, 250, .3);
        }

        .er1 {
            color: #cc0033;
            font-family: Helvetica, Arial, sans-serif;
            font-size: 13px;
            font-weight: bold;
            line-height: 20px;
            text-shadow: 1px 1px rgba(250, 250, 250, .3);
        }
    </style>
</head>

<body>
</body>

</html>